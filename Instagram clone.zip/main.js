let num = [3, 5, 1, 2, 3, 5]
//for(let i=0; i<num.length; i++){
// console.log(num)
 // console.log(num[i])
//}
//forEach ...loop
/*num.forEach((element)=>{
  console.log(element*element);
})*/


//Array.from
/*let a = document.getElementById(footer);
console.log(typeof a);

//a.forEach();
Array.from(a);
console.log(a);  */

/*
let name = 'ali';
let arr = Array.from(name);
console.log(arr);
*/

for(let i of num){
  console.log(i);
}




